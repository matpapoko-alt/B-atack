import http from "node:http";
import crypto from "node:crypto";
import { WebSocketServer, WebSocket } from "ws";

const PORT = Number(process.env.PORT || 8080);
const HEARTBEAT_MS = 15_000;
const ROOM_TTL_MS = 30 * 60_000;
const MAX_MESSAGE_BYTES = 8 * 1024;
const TICK_MS = 50;
const rooms = new Map();
const clients = new Map();

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ ok: true, rooms: rooms.size }));
    return;
  }
  res.writeHead(200, { "content-type": "text/plain; charset=utf-8" });
  res.end("Back Attack multiplayer server is running.\\n");
});

const wss = new WebSocketServer({
  server,
  maxPayload: MAX_MESSAGE_BYTES,
  perMessageDeflate: false
});

function send(ws, type, data = {}) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type, ...data }));
}
function broadcast(room, type, data = {}) {
  for (const player of room.players.values()) {
    if (player.ws) send(player.ws, type, data);
  }
}
function randomCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  for (let attempt = 0; attempt < 100; attempt++) {
    let code = "";
    for (let i = 0; i < 6; i++) code += alphabet[crypto.randomInt(alphabet.length)];
    if (!rooms.has(code)) return code;
  }
  throw new Error("Impossible de générer un code de salon unique.");
}
function publicRoom(room) {
  return {
    code: room.code,
    status: room.status,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, ready: p.ready, alive: p.alive
    })),
    maxPlayers: 4,
    mapId: room.mapId,
    state: room.state
  };
}
function sendRoom(room) {
  broadcast(room, "room:update", { room: publicRoom(room) });
}
function playerBySocket(ws) {
  const info = clients.get(ws);
  if (!info) return null;
  const room = rooms.get(info.roomCode);
  const player = room?.players.get(info.playerId);
  return room && player ? { room, player, info } : null;
}
function safeName(value) {
  if (typeof value !== "string") return "Joueur";
  return value.trim().replace(/[<>]/g, "").slice(0, 18) || "Joueur";
}
function createRoom(ws, msg) {
  const code = randomCode();
  const playerId = crypto.randomUUID();
  const reconnectToken = crypto.randomBytes(24).toString("hex");
  const room = {
    code, status: "lobby", createdAt: Date.now(), lastActive: Date.now(),
    mapId: typeof msg.mapId === "string" ? msg.mapId.slice(0, 40) : "map-1",
    players: new Map(),
    state: {
      tick: 0, startedAt: null, elapsedMs: 0, remainingMs: 120_000,
      rails: null, vehicles: {}, projectiles: [], boosts: [], scores: {},
      winnerId: null
    },
    pendingInputs: new Map()
  };
  const player = {
    id: playerId, name: safeName(msg.name), ws, reconnectToken,
    ready: false, alive: true, score: 0, lastSeen: Date.now(),
    input: { direction: null, boost: false, fire: false },
    vehicle: { node: "start", edge: null, progress: 0, facing: "right", speed: 0.7, boostUntil: 0 }
  };
  room.players.set(playerId, player);
  room.state.vehicles[playerId] = player.vehicle;
  room.state.scores[playerId] = 0;
  rooms.set(code, room);
  clients.set(ws, { roomCode: code, playerId });
  send(ws, "room:created", { code, playerId, reconnectToken, room: publicRoom(room) });
  sendRoom(room);
}
function joinRoom(ws, msg) {
  const code = String(msg.code || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
  const room = rooms.get(code);
  if (!room) return send(ws, "error", { code: "ROOM_NOT_FOUND", message: "Salon introuvable." });
  if (room.status !== "lobby") return send(ws, "error", { code: "GAME_STARTED", message: "Cette partie a déjà commencé." });
  if (room.players.size >= 4) return send(ws, "error", { code: "ROOM_FULL", message: "Ce salon contient déjà 4 joueurs." });
  const playerId = crypto.randomUUID();
  const reconnectToken = crypto.randomBytes(24).toString("hex");
  const player = {
    id: playerId, name: safeName(msg.name), ws, reconnectToken,
    ready: false, alive: true, score: 0, lastSeen: Date.now(),
    input: { direction: null, boost: false, fire: false },
    vehicle: { node: "start", edge: null, progress: 0, facing: "right", speed: 0.7, boostUntil: 0 }
  };
  room.players.set(playerId, player);
  room.state.vehicles[playerId] = player.vehicle;
  room.state.scores[playerId] = 0;
  room.lastActive = Date.now();
  clients.set(ws, { roomCode: code, playerId });
  send(ws, "room:joined", { code, playerId, reconnectToken, room: publicRoom(room) });
  sendRoom(room);
}
function reconnect(ws, msg) {
  const code = String(msg.code || "").toUpperCase();
  const room = rooms.get(code);
  const player = room?.players.get(String(msg.playerId || ""));
  if (!player || !msg.reconnectToken || player.reconnectToken !== msg.reconnectToken) {
    return send(ws, "error", { code: "RECONNECT_FAILED", message: "Reconnexion impossible. Rejoignez à nouveau le salon." });
  }
  if (player.ws && player.ws !== ws) {
    try { player.ws.close(4001, "Session remplacée"); } catch {}
    clients.delete(player.ws);
  }
  player.ws = ws;
  player.lastSeen = Date.now();
  clients.set(ws, { roomCode: code, playerId: player.id });
  send(ws, "room:reconnected", { code, playerId: player.id, room: publicRoom(room) });
  sendRoom(room);
}
function startGame(room) {
  if (room.status !== "lobby") return;
  if (room.players.size < 2) return;
  if (![...room.players.values()].every(p => p.ready)) return;
  room.status = "countdown";
  room.state.startedAt = Date.now() + 3000;
  broadcast(room, "game:countdown", { startsAt: room.state.startedAt });
  setTimeout(() => {
    if (room.status !== "countdown") return;
    room.status = "playing";
    room.state.startedAt = Date.now();
    room.state.remainingMs = 120_000;
    broadcast(room, "game:started", { room: publicRoom(room) });
    sendRoom(room);
  }, 3000);
}
function handleMessage(ws, raw) {
  let msg;
  try { msg = JSON.parse(raw.toString()); } catch {
    return send(ws, "error", { code: "BAD_JSON", message: "Message JSON invalide." });
  }
  if (!msg || typeof msg.type !== "string") return;
  if (msg.type === "room:create") return createRoom(ws, msg);
  if (msg.type === "room:join") return joinRoom(ws, msg);
  if (msg.type === "room:reconnect") return reconnect(ws, msg);

  const context = playerBySocket(ws);
  if (!context) return send(ws, "error", { code: "NOT_IN_ROOM", message: "Créez ou rejoignez un salon." });
  const { room, player } = context;
  room.lastActive = Date.now();
  player.lastSeen = Date.now();

  switch (msg.type) {
    case "player:ready":
      if (room.status !== "lobby") break;
      player.ready = Boolean(msg.ready);
      sendRoom(room);
      if (msg.start === true && room.players.size >= 2) {
        // N'importe quel joueur peut demander le départ, mais tout le monde doit être prêt.
        startGame(room);
      }
      break;
    case "game:start":
      startGame(room);
      break;
    case "game:input": {
      if (room.status !== "playing" || !player.alive) break;
      const direction = ["up", "down", "left", "right"].includes(msg.direction) ? msg.direction : null;
      player.input = {
        direction,
        boost: msg.boost === true,
        fire: msg.fire === true
      };
      break;
    }
    case "game:map":
      if (room.status === "lobby" && typeof msg.mapId === "string") {
        room.mapId = msg.mapId.slice(0, 40);
        sendRoom(room);
      }
      break;
    case "room:leave":
      removePlayer(room, player.id);
      clients.delete(ws);
      send(ws, "room:left", {});
      break;
    default:
      send(ws, "error", { code: "UNKNOWN_EVENT", message: "Événement non reconnu." });
  }
}
function removePlayer(room, playerId) {
  const player = room.players.get(playerId);
  if (!player) return;
  room.players.delete(playerId);
  delete room.state.vehicles[playerId];
  delete room.state.scores[playerId];
  if (room.players.size === 0) rooms.delete(room.code);
  else sendRoom(room);
}
wss.on("connection", ws => {
  clients.set(ws, null);
  ws.on("message", raw => handleMessage(ws, raw));
  ws.on("close", () => {
    const info = clients.get(ws);
    clients.delete(ws);
    if (!info) return;
    const room = rooms.get(info.roomCode);
    const player = room?.players.get(info.playerId);
    if (player && player.ws === ws) {
      player.ws = null; // Conserve la place temporairement pour permettre la reconnexion.
      player.lastSeen = Date.now();
      if (room) sendRoom(room);
    }
  });
  ws.on("error", () => {});
  send(ws, "server:hello", { protocol: 1, maxPlayers: 4 });
});

setInterval(() => {
  const now = Date.now();
  for (const room of rooms.values()) {
    for (const [id, player] of room.players) {
      if (!player.ws && now - player.lastSeen > 60_000) removePlayer(room, id);
    }
    if (rooms.has(room.code) && now - room.lastActive > ROOM_TTL_MS) {
      for (const p of room.players.values()) {
        if (p.ws) send(p.ws, "room:expired", {});
      }
      rooms.delete(room.code);
    }
  }
}, HEARTBEAT_MS).unref();

setInterval(() => {
  const now = Date.now();
  for (const room of rooms.values()) {
    if (room.status !== "playing") continue;
    room.state.tick++;
    room.state.elapsedMs = now - room.state.startedAt;
    room.state.remainingMs = Math.max(0, 120_000 - room.state.elapsedMs);

    // IMPORTANT : ceci est le squelette réseau. La simulation exacte des rails,
    // projectiles, boosts et collisions doit être raccordée aux données du jeu existant.
    // Le serveur conserve l'autorité sur l'état et ne prend pas les positions du client.
    for (const p of room.players.values()) {
      if (!p.alive) continue;
      if (p.input.boost) p.vehicle.boostUntil = Math.max(p.vehicle.boostUntil || 0, now + 2500);
      p.vehicle.speed = (p.vehicle.boostUntil || 0) > now ? 1.3 : 0.7;
      p.input.boost = false;
      p.input.fire = false;
      room.state.vehicles[p.id] = p.vehicle;
      room.state.scores[p.id] = p.score;
    }
    broadcast(room, "game:state", {
      state: {
        tick: room.state.tick,
        remainingMs: room.state.remainingMs,
        vehicles: room.state.vehicles,
        scores: room.state.scores,
        projectiles: room.state.projectiles,
        boosts: room.state.boosts,
        status: room.status
      }
    });
    if (room.state.remainingMs <= 0) {
      room.status = "finished";
      const standings = [...room.players.values()].sort((a, b) => b.score - a.score);
      room.state.winnerId = standings[0]?.id || null;
      broadcast(room, "game:finished", {
        winnerId: room.state.winnerId,
        standings: standings.map(p => ({ id: p.id, name: p.name, score: p.score }))
      });
      sendRoom(room);
    }
  }
}, TICK_MS).unref();

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Back Attack server listening on port ${PORT}`);
});
